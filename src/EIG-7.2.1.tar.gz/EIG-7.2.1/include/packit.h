int packmode = NO;
unsigned char *packgenos = NULL;
long packlen = 0;
long rlen = -1;
int rdismode = NO;
unsigned char *packepath;
